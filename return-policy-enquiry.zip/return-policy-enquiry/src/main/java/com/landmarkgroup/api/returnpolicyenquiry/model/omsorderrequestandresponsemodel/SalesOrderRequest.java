package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
public class SalesOrderRequest {
    @NonNull
    private String enterprise_code;

    @NonNull
    private String entry_type;

    private BigDecimal document_type;

    @NonNull
    private String customer_order_number;
}
