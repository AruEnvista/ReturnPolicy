package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.math.BigDecimal;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnpolicydb")
public class SalesOrderResponse {
    @NonNull
    private String enterprise_code;

    private BigDecimal document_type;

    private String order_date;

    private String source;

    private boolean isRTS = false;

    private boolean is_guest_user = false;

    private String shukran_loyalty_card_no;

    @NonNull
    @Field("order_number")
    private String orderNumber;

    private List<SalesOrderLines> order_lines;

    private List<HeaderCharge> header_charges;

    private List<HeaderTax> header_taxes;

    private List<PaymentMethod> payment_methods;

    private Boolean isLegacyOrder=false;

    private List<String> statusList ;

}
